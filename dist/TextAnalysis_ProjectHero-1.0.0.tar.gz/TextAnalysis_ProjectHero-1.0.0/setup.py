from setuptools import find_packages, setup

setup(
        author = 'Louie Tran',
        description = " A package used for inputing, processing, exporting text for a specific research project",
        name = 'TextAnalysis_ProjectHero',
        version = '1.0.0',
        packages = find_packages(include=['TextAnalysis_ProjectHero','TextAnalysis_ProjectHero.*']),
)