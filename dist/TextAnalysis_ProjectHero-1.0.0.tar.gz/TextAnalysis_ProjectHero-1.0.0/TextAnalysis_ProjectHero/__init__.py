"""
This package process extracted text from published articles
"""

from TextAnalysis_ProjectHero.data_processing import export_16